import AuthForm from '../components/auth/AuthForm';

const AuthPage = () => {
  return <AuthForm style={{ paddingTop: '20px' }} />;
};

export default AuthPage;
